/* this header file is to be removed soon. */
#include "mruby/opcode.h"
