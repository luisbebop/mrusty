/* this header file is to be removed soon.
   added for compatibility purpose (1.0.0) */
#include "mruby/error.h"
